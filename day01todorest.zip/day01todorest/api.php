<?php

require_once 'vendor/autoload.php';

use Respect\Validation\Validator as Validator;

use Slim\Http\Request;
use Slim\Http\Response;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

// create a log channel
$log = new Logger('main');
$log->pushHandler(new StreamHandler(dirname(__FILE__) . '/logs/everything.log', Logger::DEBUG));
$log->pushHandler(new StreamHandler(dirname(__FILE__) . '/logs/errors.log', Logger::ERROR));

DB::$dbName = 'day01todorest';
DB::$user = 'day01todorest';
DB::$password = 'GrR.xtOebGo5cgvX';
DB::$port = 3333;

DB::$error_handler = 'db_error_handler'; // runs on mysql query errors
DB::$nonsql_error_handler = 'db_error_handler'; // runs on library errors (bad syntax, etc)

function db_error_handler($params)
{
    global $log;
    // log first
    $log->error("Database error: " . $params['error']);
    if (isset($params['query'])) {
        $log->error("SQL query: " . $params['query']);
    }
    http_response_code(500); // internal server error
    header('Content-type: application/json; charset=UTF-8');
    die(json_encode("500 - Internal server error"));
}



use Slim\Http\UploadedFile;

// Create and configure Slim app
$config = ['settings' => [
    'addContentLengthHeader' => false,
    'displayErrorDetails' => true
]];
$app = new \Slim\App($config);

// Fetch DI Container
$container = $app->getContainer();

// File upload directory
$container['upload_directory'] = __DIR__ . '/uploads';

//Override the default Not Found Handler before creating App
$container['notFoundHandler'] = function ($container) {
    return function ($request, $response) use ($container) {
        $response = $response->withHeader('Content-type', 'application/json; charset=UTF-8');
        $response = $response->withStatus(404);
        $response->getBody()->write(json_encode("404 - not found"));
        return $response;
    };
};

$passwordPepper = 'mmyb7oSAeXG9DTz2uFqu';


// set content-type globally using middleware (untested)
$app->add(function ($request, $response, $next) {
    sleep(1); // artificially delay all responses by 1 second
    $response = $next($request, $response);
    return $response->withHeader('Content-Type', 'application/json; charset=UTF-8');
});

// ============= URL HANDLERS BELOW THIS LINE ========================

$app->get('/', function (Request $request, Response $response, array $args) {
    $response->getBody()->write("Todo app RESTful API");
    return $response;
});

$app->group('/api', function () use ($app) {

    $app->get('/todos', function (Request $request, Response $response, array $args) {
        $userId = getAuthUserId($request);
        if (!$userId) {
            $response = $response->withStatus(403);
            $response->getBody()->write(json_encode("403 - authentication failed"));
            return $response;
        }
        $sortBy = $request->getQueryParam('sortBy', 'id');
        if (!in_array($sortBy, ['id', 'task','dueDate','isDone'])) {
            $response = $response->withStatus(400);
            $response->getBody()->write(json_encode("400 - invalid sortBy value"));
            return $response;
        }
        $list = DB::query("SELECT * FROM todos WHERE ownerId=%i ORDER BY %l", $userId, $sortBy);
        $json = json_encode($list, JSON_PRETTY_PRINT);
        return $response->getBody()->write($json);
    });

    $app->get('/todos/{id:[0-9]+}', function (Request $request, Response $response, array $args) {
        $userId = getAuthUserId($request);
        if (!$userId) {
            $response = $response->withStatus(403);
            $response->getBody()->write(json_encode("403 - authentication failed"));
            return $response;
        }
        $item = DB::queryFirstRow("SELECT * FROM todos WHERE id=%i AND ownerId=%i", $args['id'], $userId);
        if (!$item) {
            $response = $response->withStatus(404);
            $response->getBody()->write(json_encode("404 - not found"));
            return $response;
        }
        $json = json_encode($item, JSON_PRETTY_PRINT);
        return $response->getBody()->write($json);
    });

    $app->post('/todos', function (Request $request, Response $response, array $args) {
        $userId = getAuthUserId($request);
        if (!$userId) {
            $response = $response->withStatus(403);
            $response->getBody()->write(json_encode("403 - authentication failed"));
            return $response;
        }
        $json = $request->getBody();
        $item = json_decode($json, TRUE);
        // validate
        if (($result = validateTodo($item)) !== TRUE) {
            $response = $response->withStatus(400);
            $response->getBody()->write(json_encode("400 - " . $result));
            return $response;
        }
        //
        $item['ownerId'] = $userId;
        DB::insert('todos', $item);
        $insertId = DB::insertId();
        $response = $response->withStatus(201); // created
        $response->getBody()->write(json_encode($insertId));
        return $response;
    });

    $app->map(['PUT', 'PATCH'], '/todos/{id:[0-9]+}', function (Request $request, Response $response, array $args) {
        $userId = getAuthUserId($request);
        if (!$userId) {
            $response = $response->withStatus(403);
            $response->getBody()->write(json_encode("403 - authentication failed"));
            return $response;
        }
        $json = $request->getBody();
        $item = json_decode($json, TRUE);
        // validate
        $method = $request->getMethod();
        if (($result = validateTodo($item, $method == 'PATCH')) !== TRUE) {
            $response = $response->withStatus(400);
            $response->getBody()->write(json_encode("400 - " . $result));
            return $response;
        }
        // only update a record belonging to the authenticated user
        $origItem = DB::queryFirstRow("SELECT * FROM todos WHERE id=%i AND ownerId=%i", $args['id'], $userId);
        if (!$origItem) {
            $response = $response->withStatus(404);
            $response->getBody()->write(json_encode("404 - not found"));
            return $response;
        }
        // perform update
        DB::update('todos', $item, "id=%i AND ownerId=%i", $args['id'], $userId);
        // Can't use $affected = DB::affectedRows(); because it returns 0 if no data was changed
        $response->getBody()->write(json_encode(true));
        return $response;
    });

    $app->delete('/todos/{id:[0-9]+}', function (Request $request, Response $response, array $args) {
        $userId = getAuthUserId($request);
        if (!$userId) {
            $response = $response->withStatus(403);
            $response->getBody()->write(json_encode("403 - authentication failed"));
            return $response;
        }
        DB::delete('todos', 'id=%i AND ownerId=%i', $args['id'], $userId);
        $count = DB::affectedRows();
        return $response->getBody()->write(json_encode($count != 0));
    });

    $app->post('/users', function (Request $request, Response $response, array $args) {
        // WARNING: in a real-world system you must protect this API call from abuse
        // where someone could try to create many, many users using a robot
        // you could use captcha and/or rate-limiting to accomplish that
        $json = $request->getBody();
        $item = json_decode($json, TRUE);
        // validate
        if (($result = validateUser($item)) !== TRUE) {
            $response = $response->withStatus(400);
            $response->getBody()->write(json_encode("400 - " . $result));
            return $response;
        }
        $item['image'] = base64_decode($item['image']);
        // create the user
        DB::insert('users', $item);
        $insertId = DB::insertId();
        $response = $response->withStatus(201); // created
        $response->getBody()->write(json_encode($insertId));
        return $response;
    });

}); // close /api group (prefix)

// returns TRUE if todo is valid, otherwise returns a string describing the problem
function validateTodo($todo, $forPatch = false)
{
    // json_decode return null if JSON syntax is invalid
    if ($todo == NULL) {
        return "Invalid JSON data provided";
    }
    //
    $expectedFields = ['task', 'dueDate', 'isDone'];
    // make sure no other fields are present
    $todoFields = array_keys($todo); // get names of fields as an array
    if ($diff = array_diff($todoFields, $expectedFields)) {
        return "Invalid fields in Todo: [" . implode(',', $diff) . "]";
    }
    // make sure that all the necessary fields are present: 'task', 'dueDate', 'isDone'
    if (!$forPatch) { // do not require all fields present if PATCH is taking place
        if ($diff = array_diff($expectedFields, $todoFields)) {
            return "Missing fields in Todo: [" . implode(',', $diff) . "]";
        }
    }
    // validate task - 1-100 characters long
    if (isset($todo['task'])) {
        if ((strlen($todo['task']) < 1 || strlen($todo['task']) > 100)) {
            return "Task description must be 1-100 characters long";
        }
    }
    // validate dueDate - format yyyy-mm-dd, year range 2000-2099
    if (isset($todo['dueDate'])) {
        if (!date_create_from_format('Y-m-d', $todo['dueDate'])) {
            return "DueDate has invalid format";
        }
        $dueDate = strtotime($todo['dueDate']);
        if ($dueDate < strtotime('1900-01-01') || $dueDate >= strtotime('2100-01-01')) {
            return "DueDate must be within 1900 to 2099 years";
        }
    }
    // validate isDone - either 'pending' or 'done'
    if (isset($todo['isDone'])) {
        if (!in_array($todo['isDone'], ['pending', 'done'])) {
            return "IsDone invalid: must be either pending or done";
        }
    }
    return TRUE; // if we made it here then no problems were found
}

// returns TRUE if todo is valid, otherwise returns a string describing the problem
function validateUser($user)
{
    // json_decode return null if JSON syntax is invalid
    if ($user == NULL) {
        return "Invalid JSON data provided";
    }
    //
    $expectedFields = ['email', 'password', 'image', 'imageMimeType'];
    // make sure no other fields are present
    $userFields = array_keys($user); // get names of fields as an array
    if ($diff = array_diff($userFields, $expectedFields)) {
        return "Invalid fields in User: [" . implode(',', $diff) . "]";
    }
    // make sure that all the necessary fields are present: 'email', 'password'
    if ($diff = array_diff($expectedFields, $userFields)) {
        return "Missing fields in User: [" . implode(',', $diff) . "]";
    }
    // FIXME: make sure that imageMimeType is one of the allowed types: jpg, gif, png

    // email must look like an email
    if (filter_var($user['email'], FILTER_VALIDATE_EMAIL) === false) {
        return "Email is invalid";
    }
    // user with this email must not exist yet
    if (DB::queryFirstRow("SELECT id FROM users WHERE email=%s", $user['email'])) {
        return "Email already registered by another user";
    }
    // check password quality, at minimum: one uppercase, one lowercase, one digit, pass len minimum 6 chars
    $pass = $user['password'];
    if (strlen($pass) < 6 || (preg_match('/[A-Z]/', $pass) != 1) || (preg_match('/[a-z]/', $pass) !=1 )|| (preg_match('/[0-9]/', $pass) != 1) ) {
        return "Password invalid, must be at least 6 characters, one uppercase, one lowercase, one digit";
    }
    return TRUE; // if we made it here then no problems were found
}

function getAuthUserId(Request $request) {
    if (!$request->hasHeader('X-auth-username') || !$request->hasHeader('X-auth-password')) {
        return FALSE;
    }
    $username = $request->getHeader('X-auth-username')[0];
    $password = $request->getHeader('X-auth-password')[0];
    $user = DB::queryFirstRow("SELECT * FROM users WHERE email=%s", $username);
    $userId = FALSE;
    if ($user) {
        if ($user['password'] == $password) {
            $userId = $user['id'];
        }
    }
    return $userId;
}


// Run app
$app->run();
