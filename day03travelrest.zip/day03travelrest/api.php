<?php

require_once 'vendor/autoload.php';

use Respect\Validation\Validator as Validator;

use Slim\Http\Request;
use Slim\Http\Response;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

// create a log channel
$log = new Logger('main');
$log->pushHandler(new StreamHandler(dirname(__FILE__) . '/logs/everything.log', Logger::DEBUG));
$log->pushHandler(new StreamHandler(dirname(__FILE__) . '/logs/errors.log', Logger::ERROR));

DB::$dbName = 'day03travelrest';
DB::$user = 'day03travelrest';
DB::$password = 'R-UyuWa.Ok4IWqzi';
DB::$port = 3333;

DB::$error_handler = 'db_error_handler'; // runs on mysql query errors
DB::$nonsql_error_handler = 'db_error_handler'; // runs on library errors (bad syntax, etc)

function db_error_handler($params)
{
    global $log;
    // log first
    $log->error("Database error: " . $params['error']);
    if (isset($params['query'])) {
        $log->error("SQL query: " . $params['query']);
    }
    http_response_code(500); // internal server error
    header('Content-type: application/json; charset=UTF-8');
    die(json_encode("500 - Internal server error"));
}



use Slim\Http\UploadedFile;

// Create and configure Slim app
$config = ['settings' => [
    'addContentLengthHeader' => false,
    'displayErrorDetails' => true
]];
$app = new \Slim\App($config);

// Fetch DI Container
$container = $app->getContainer();

// File upload directory
$container['upload_directory'] = __DIR__ . '/uploads';

//Override the default Not Found Handler before creating App
$container['notFoundHandler'] = function ($container) {
    return function ($request, $response) use ($container) {
        $response = $response->withHeader('Content-type', 'application/json; charset=UTF-8');
        $response = $response->withStatus(404);
        $response->getBody()->write(json_encode("404 - not found"));
        return $response;
    };
};

$passwordPepper = 'mmyb7oSAeXG9DTz2uFqu';


// set content-type globally using middleware (untested)
$app->add(function ($request, $response, $next) {
    sleep(1); // artificially delay all responses by 1 second
    $response = $next($request, $response);
    return $response->withHeader('Content-Type', 'application/json; charset=UTF-8');
});

// ============= URL HANDLERS BELOW THIS LINE ========================

$app->get('/', function (Request $request, Response $response, array $args) {
    $response->getBody()->write("Travel app RESTful API");
    return $response;
});

$app->group('/api', function () use ($app) {
    // GET - list of travellers
    $app->get('/travellers', function (Request $request, Response $response, array $args) {
        
        $sortBy = $request->getQueryParam('sortBy', 'id');
        if (!in_array($sortBy, ['id', 'name','destination','departureDate', 'returnDate'])) {
            $response = $response->withStatus(400);
            $response->getBody()->write(json_encode("400 - invalid sortBy value"));
            return $response;
        }
        $list = DB::query("SELECT * FROM travellers ORDER BY %l", $sortBy);
        // error if travellers table is not found
        if (!$list) {
            $response = $response->withStatus(404);
            return $response->getBody()->write(json_encode("404 - not found"));
        }
        $json = json_encode($list, JSON_PRETTY_PRINT);
        return $response->getBody()->write($json);
    });

    //GET - one traveller from the list
    $app->get('/travellers/{id:[0-9]+}', function (Request $request, Response $response, array $args) {
        $item = DB::queryFirstRow("SELECT * FROM travellers WHERE id=%i", $args['id']);
        if (!$item) {
            $response = $response->withStatus(404);
            $response->getBody()->write(json_encode("404 - not found"));
            return $response;
        }
        $json = json_encode($item, JSON_PRETTY_PRINT);
        return $response->getBody()->write($json);
    });

    $app->post('/travellers', function (Request $request, Response $response, array $args) {
        $json = $request->getBody();
        $item = json_decode($json, TRUE);
        // validate
        if (($result = validateTraveller($item)) !== TRUE) {
            $response = $response->withStatus(400);
            $response->getBody()->write(json_encode("400 - " . $result));
            return $response;
        }
        DB::insert('travellers', $item);
        $insertId = DB::insertId();
        $response = $response->withStatus(201); // created
        $response->getBody()->write(json_encode($insertId));
        return $response;
    });

    $app->map(['PUT', 'PATCH'], '/travellers/{id:[0-9]+}', function (Request $request, Response $response, array $args) {
        $json = $request->getBody();
        $item = json_decode($json, TRUE);
        // validate
        $method = $request->getMethod();
        if (($result = validateTraveller($item, $method == 'PATCH')) !== TRUE) {
            $response = $response->withStatus(400);
            $response->getBody()->write(json_encode("400 - " . $result));
            return $response;
        }
        // perform update
        DB::update('travellers', $item, "id=%i", $args['id']);
        // Can't use $affected = DB::affectedRows(); because it returns 0 if no data was changed
        $response->getBody()->write(json_encode(true));
        return $response;
    });

    $app->delete('/travellers/{id:[0-9]+}', function (Request $request, Response $response, array $args) {
        DB::delete('travellers', 'id=%i', $args['id']);
        $count = DB::affectedRows();
        return $response->getBody()->write(json_encode($count != 0));
    });

}); // close /api group (prefix)

// returns TRUE if todo is valid, otherwise returns a string describing the problem
function validateTraveller($traveller, $forPatch = false, $patchId = null)
{
    // json_decode return null if JSON syntax is invalid
    if ($traveller == NULL) {
        return "Invalid JSON data provided";
    }
    //
    $expectedFields = ['name', 'destination', 'departureDate', 'returnDate'];
    $optionalFields = ['photo', 'photoMimeType'];

    // make sure no other fields are present
    $travellerFields = array_keys($traveller); // get names of fields as an array
    if ($diff = array_diff($travellerFields, $expectedFields)) {
        if ($diffOpt = array_diff($diff, $optionalFields)) {
            return "Invalid fields in Traveller: [" . implode(',', $diffOpt) . "]";
        }
    }
    // make sure that all the necessary fields are present: 'name', 'destination', 'departureDate', 'returnDate'
    if (!$forPatch) { // do not require all fields present if PATCH is taking place
        if ($diff = array_diff($expectedFields, $travellerFields)) {
            return "Missing fields in Traveller: [" . implode(',', $diff) . "]";
        }
    }
    // validate name - 1-50 characters long
    if (isset($traveller['name'])) {
        if ((strlen($traveller['name']) < 1 || strlen($traveller['name']) > 50)) {
            return "Name must be 1-50 characters long";
        }
    }
    // validate destination - 1-50 characters long
    if (isset($traveller['destination'])) {
        if ((strlen($traveller['destination']) < 1 || strlen($traveller['destination']) > 50)) {
            return "Destination must be 1-50 characters long";
        }
    }
    // validate departureDate - format yyyy-mm-dd
    if (isset($traveller['departureDate'])) {
        if (!date_create_from_format('Y-m-d', $traveller['departureDate'])) {
            return "Departure Date has invalid format";
        }
    }

    // validate returnDate - format yyyy-mm-dd
    if (isset($traveller['returnDate'])) {
        if (!date_create_from_format('Y-m-d', $traveller['returnDate'])) {
            return "Return Date has invalid format";
        }
    }

    if (isset($traveller['departureDate'])) {
        $departureDate = strtotime($traveller['departureDate']);
    } else {
        $queryDD = DB::queryFirstRow("SELECT * FROM travellers WHERE id=%i", $patchId);
        // error if traveller is not found
        if (!$queryDD) {
            return "404 - not found";
        }
        $departureDate = strtotime($queryDD['departureDate']);
    }

    if (isset($traveller['returnDate'])) {
        $returnDate = strtotime($traveller['returnDate']);
    } else {
        $queryRD = DB::queryFirstRow("SELECT * FROM travellers WHERE id=%i", $patchId);
        // error if traveller is not found
        if (!$queryRD) {
            return "404 - not found";
        }
        $returnDate = strtotime($queryRD['returnDate']);
    }

    // departureDate should be before returnDate
    if ($departureDate >  $returnDate) {
        return "Departure Date must be before Return Date";
    }
    
    return TRUE; // if we made it here then no problems were found
}

// Run app
$app->run();
